# MyLinkedList

Biblioteca de listas simplemente ligadas (campos INFO y LIGA).

## Instalación

Desde la carpeta del proyecto:

    pip install .

(o `pip install -e .` para modo desarrollo). También puedes simplemente
copiar la carpeta `mylinkedlist/` junto a tu script.

## Uso

    from mylinkedlist import MyLinkedList

    lista = MyLinkedList()
    lista.insertar("a")            # al final
    lista.insertar("b", 0)         # al inicio
    lista.insertar("c", 1)         # en medio
    print(lista)                   # b -> c -> a -> NIL
    lista.sobrescribir("X", 1)     # devuelve 'c'
    lista.buscar("x")              # [1]  (sin distinguir mayúsculas)
    lista.eliminar_valor("a")      # True
    lista.eliminar_posicion(0)     # 'b'
    len(lista), list(lista), "X" in lista

## Métodos

| Método | Descripción |
|---|---|
| `insertar(dato, pos=None)` | Inserta en `pos` (por defecto al final) |
| `sobrescribir(dato, pos)` | Reemplaza y devuelve el valor anterior |
| `eliminar_posicion(pos)` | Elimina y devuelve el valor |
| `eliminar_valor(x)` | Elimina la primera aparición; `True`/`False` |
| `buscar(x)` | Lista de posiciones donde aparece `x` |
| `obtener(pos)` | Valor en `pos` |
| `longitud()`, `esta_vacia()`, `recorrer()` | Utilidades |

Una posición fuera de rango lanza `IndexError`.
