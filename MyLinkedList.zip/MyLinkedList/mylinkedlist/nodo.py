class Nodo:
    """Nodo de una lista simplemente ligada: campos INFO y LIGA."""

    def __init__(self, info):
        self.info = info   # INFO
        self.liga = None   # LIGA (None equivale a NIL)

    def __repr__(self):
        return f"Nodo({self.info!r})"
