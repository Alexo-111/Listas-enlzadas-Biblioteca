"""MyLinkedList: implementación de listas simplemente ligadas."""
from .nodo import Nodo
from .lista import MyLinkedList

__all__ = ["Nodo", "MyLinkedList"]
__version__ = "1.0.0"
