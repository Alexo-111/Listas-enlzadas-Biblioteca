from .nodo import Nodo


def _iguales(a, b):
    """Compara dos valores; si son textos, ignora mayúsculas y espacios en los extremos."""
    if isinstance(a, str) and isinstance(b, str):
        return a.strip().lower() == b.strip().lower()
    return a == b


class MyLinkedList:
    """Lista simplemente ligada.

    Las posiciones empiezan en 0. Las operaciones que reciben una posición
    inválida lanzan IndexError.
    """

    def __init__(self, iterable=None):
        self.p = None  # P = NIL (lista vacía)
        if iterable is not None:
            for dato in iterable:
                self.insertar(dato, len(self))

    # ---------------- Utilidades ----------------
    def longitud(self):
        """Cuenta cuántos nodos tiene la lista."""
        cuenta = 0
        q = self.p
        while q is not None:
            cuenta += 1
            q = q.liga
        return cuenta

    def esta_vacia(self):
        return self.p is None

    def _nodo(self, pos):
        """Devuelve el nodo en la posición 'pos' (valida el rango)."""
        if pos < 0 or pos >= self.longitud():
            raise IndexError(f"Posición {pos} fuera de rango.")
        q = self.p
        for _ in range(pos):
            q = q.liga
        return q

    def obtener(self, pos):
        """Devuelve el valor guardado en la posición 'pos'."""
        return self._nodo(pos).info

    # ---------------- Inserción y sobrescritura ----------------
    def insertar(self, dato, pos=None):
        """Inserta 'dato' en la posición 'pos' (0 = inicio, longitud = final),
        desplazando los demás. Si no se da 'pos', se agrega al final."""
        n = self.longitud()
        if pos is None:
            pos = n
        if pos < 0 or pos > n:
            raise IndexError(f"Posición {pos} fuera de rango (0 a {n}).")

        nuevo = Nodo(dato)
        if pos == 0:                      # al inicio (cubre lista vacía)
            nuevo.liga = self.p
            self.p = nuevo
            return
        t = self._nodo(pos - 1)           # nodo anterior
        nuevo.liga = t.liga
        t.liga = nuevo

    def sobrescribir(self, dato, pos):
        """Reemplaza el valor en 'pos'. Devuelve el valor anterior."""
        nodo = self._nodo(pos)
        anterior = nodo.info
        nodo.info = dato
        return anterior

    # ---------------- Eliminación ----------------
    def eliminar_posicion(self, pos):
        """Elimina el nodo en 'pos'. Devuelve el valor eliminado."""
        if pos < 0 or pos >= self.longitud():
            raise IndexError(f"Posición {pos} fuera de rango.")
        if pos == 0:                      # Algoritmo 5.9
            eliminado = self.p.info
            self.p = self.p.liga
            return eliminado
        t = self._nodo(pos - 1)
        q = t.liga
        t.liga = q.liga
        return q.info

    def eliminar_valor(self, x):
        """Algoritmo 5.11 (Elimina_X): elimina la primera aparición de x.
        Devuelve True si se encontró, False si no."""
        q = self.p
        t = None
        while q is not None and not _iguales(q.info, x):
            t = q
            q = q.liga
        if q is None:
            return False
        if t is None:
            self.p = q.liga
        else:
            t.liga = q.liga
        return True

    # ---------------- Búsqueda ----------------
    def buscar(self, x):
        """Algoritmo 5.13: devuelve la lista de posiciones donde aparece x."""
        posiciones = []
        q = self.p
        pos = 0
        while q is not None:
            if _iguales(q.info, x):
                posiciones.append(pos)
            q = q.liga
            pos += 1
        return posiciones

    def contiene(self, x):
        return bool(self.buscar(x))

    # ---------------- Recorrido ----------------
    def recorrer(self):
        """Algoritmo 5.3: imprime la lista con sus posiciones."""
        if self.p is None:
            print("  (la lista está vacía)")
            return
        for i, dato in enumerate(self):
            print(f"  [{i}] {dato}")

    def __iter__(self):
        q = self.p
        while q is not None:
            yield q.info
            q = q.liga

    def __len__(self):
        return self.longitud()

    def __contains__(self, x):
        return self.contiene(x)

    def __getitem__(self, pos):
        return self.obtener(pos)

    def __repr__(self):
        return "MyLinkedList([" + ", ".join(repr(d) for d in self) + "])"

    def __str__(self):
        return " -> ".join(str(d) for d in self) + " -> NIL" if self.p else "NIL"
