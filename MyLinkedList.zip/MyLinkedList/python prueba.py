from mylinkedlist import MyLinkedList

lista = MyLinkedList()
lista.insertar("hola")         # al final
lista.insertar("mundo", 0)     # al inicio
lista.insertar("amigo", 1)     # en medio

print(lista)                   # mundo -> amigo -> hola -> NIL
print("Longitud:", len(lista))
print("Posiciones de 'HOLA':", lista.buscar("HOLA"))

lista.eliminar_valor("amigo")
print(lista)                   # mundo -> hola -> NIL