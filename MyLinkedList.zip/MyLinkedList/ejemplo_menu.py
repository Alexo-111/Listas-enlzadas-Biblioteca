"""Tu programa original, ahora usando la biblioteca MyLinkedList."""
from mylinkedlist import MyLinkedList


def pedir_entero(mensaje, minimo, maximo):
    while True:
        try:
            valor = int(input(mensaje))
            if minimo <= valor <= maximo:
                return valor
            print(f"Valor inválido. Debe estar entre {minimo} y {maximo}.")
        except ValueError:
            print("Debe escribir un número entero.")


def pedir_si_no(mensaje):
    while True:
        r = input(mensaje + " (s/n): ").strip().lower()
        if r in ("s", "si", "sí"):
            return True
        if r in ("n", "no"):
            return False
        print("Responda 's' o 'n'.")


def opcion_agregar(lista):
    dato = input("Valor a agregar: ")
    n = len(lista)
    if n == 0:
        lista.insertar(dato, 0)
        print("La lista estaba vacía, el dato se agregó en la posición 0.")
        return
    pos = pedir_entero(
        f"¿En qué posición desea agregarlo? (0 = inicio, {n} = final, otra = en medio): ",
        0, n)
    if pos < n:
        actual = lista.obtener(pos)
        print(f"La posición {pos} ya contiene: '{actual}'")
        if pedir_si_no("¿Desea sobrescribir ese valor?"):
            lista.sobrescribir(dato, pos)
            print(f"'{actual}' fue reemplazado por '{dato}' en la posición {pos}.")
            return
        print("No se sobrescribe; el dato se insertará y los demás se desplazan.")
    lista.insertar(dato, pos)
    print(f"'{dato}' agregado en la posición {pos}.")


def opcion_eliminar(lista):
    n = len(lista)
    if n == 0:
        print("La lista está vacía, no hay nada que eliminar.")
        return
    print("\n  1. Eliminar por posición")
    print("  2. Eliminar por valor")
    modo = input("  Opción: ")
    if modo == "1":
        print("\nContenido actual:")
        lista.recorrer()
        pos = pedir_entero(f"Posición a eliminar (0 a {n - 1}): ", 0, n - 1)
        print(f"'{lista.eliminar_posicion(pos)}' fue eliminado de la posición {pos}.")
    elif modo == "2":
        x = input("Valor a eliminar: ")
        if lista.eliminar_valor(x):
            print(f"Se eliminó la primera aparición de '{x}'.")
        else:
            print(f"'{x}' no se encuentra en la lista.")
    else:
        print("Opción no válida.")


def opcion_buscar(lista):
    if lista.esta_vacia():
        print("La lista está vacía.")
        return
    x = input("Valor a buscar: ")
    posiciones = lista.buscar(x)
    if posiciones:
        print(f"'{x}' sí se encuentra, en la(s) posición(es): "
              + ", ".join(map(str, posiciones)))
    else:
        print(f"'{x}' no se encuentra en la lista.")


def menu():
    lista = MyLinkedList()
    while True:
        print("\n--- MENÚ ---")
        print("1. Agregar un dato\n2. Eliminar un dato\n3. Buscar un dato")
        print("4. Mostrar la lista\n5. Salir")
        opcion = input("Opción: ")
        if opcion == "1":
            opcion_agregar(lista)
        elif opcion == "2":
            opcion_eliminar(lista)
        elif opcion == "3":
            opcion_buscar(lista)
        elif opcion == "4":
            print("\nContenido de la lista:")
            lista.recorrer()
        elif opcion == "5":
            print("Hasta luego.")
            break
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    menu()
